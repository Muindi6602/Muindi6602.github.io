##A simple hotspot billing using PHP by Muindi

##Open localhost/phpMyAdmin

##Create a new database and name it Manchester.

##import the database from the Database folder (muindi_wireless.sql) and save.

##localhost/muindi_wireless is the default index which opens the login form of the client.

##signup for a user to get started

##for he Admin Dashboard, click (in the login page of client), the settings icon in bottom right

##as Admin, you can spy into clients accounts by just using their phone numbers, this feature is available in the admin dashboard in the profile icon.Spy

## the default admin login details are: email = admin@gmail,com and password as 123456

## for mpesa tool, use your keys as I've excluded them for a security purpose

## For email services (sending bulk mails and password reset emails, use your credentials: create an app in your gmail account and extract the app password)

## add and manage packages in the Admin dashboard

##for additional features, contact me via WhatsApp +254115783375